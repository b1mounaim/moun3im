
    <script src="public/static/jquery/jquery-3.1.1.slim.min.js"></script>
    <script src="public/static/tether/tether.min.js"></script>
    <script src="public/static/js/bootstrap.min.js" ></script>

<?php mysqli_close($conn);?>
    </body>
</html>